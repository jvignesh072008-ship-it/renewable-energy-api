package com.renewable.distribution.controller;
import com.renewable.distribution.dto.DailyReportResponse;
import com.renewable.distribution.dto.DistributionRequest;
import com.renewable.distribution.dto.DistributionResponse;
import com.renewable.distribution.dto.client.AlertDto;
import com.renewable.distribution.service.DistributionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequiredArgsConstructor
public class DistributionController {
    private final DistributionService distributionService;
    @PostMapping("/distribution/balance")
    public ResponseEntity<DistributionResponse> balance(@Valid @RequestBody DistributionRequest request) {
        return ResponseEntity.ok(distributionService.balance(request));
    }
    @GetMapping("/reports/daily")
    public ResponseEntity<DailyReportResponse> getDailyReport() {
        return ResponseEntity.ok(distributionService.getDailyReport());
    }
    @GetMapping("/faults")
    public ResponseEntity<List<AlertDto>> getFaults() {
        return ResponseEntity.ok(distributionService.getAllFaults());
    }
}

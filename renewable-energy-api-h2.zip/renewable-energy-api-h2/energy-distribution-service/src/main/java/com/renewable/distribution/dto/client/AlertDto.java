package com.renewable.distribution.dto.client;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AlertDto {
    private Long deviceId;
    private String deviceName;
    private String deviceType;
    private String alertType;
    private String message;
    private LocalDateTime detectedAt;
}

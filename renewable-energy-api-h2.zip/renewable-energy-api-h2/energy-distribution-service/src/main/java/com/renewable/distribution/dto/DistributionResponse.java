package com.renewable.distribution.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DistributionResponse {
    private Double requiredLoadKwh;
    private Double solarUsedKwh;
    private Double windUsedKwh;
    private Double totalRenewableUsedKwh;
    private Double batteryUsedKwh;
    private Double excessStoredKwh;
    private Double unmetDemandKwh;
    private String summary;
    private List<String> batteryOperations;
    private LocalDateTime timestamp;
}

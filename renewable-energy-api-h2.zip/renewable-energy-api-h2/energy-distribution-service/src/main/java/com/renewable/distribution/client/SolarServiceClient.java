package com.renewable.distribution.client;
import com.renewable.distribution.dto.client.DailyTotalDto;
import com.renewable.distribution.dto.client.DeviceDto;
import com.renewable.distribution.dto.client.AlertDto;
import com.renewable.distribution.dto.client.GenerationRecordDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
@Component
@RequiredArgsConstructor
@Slf4j
public class SolarServiceClient {
    private final RestTemplate restTemplate;
    @Value("${services.solar.url}")
    private String solarServiceUrl;
    public List<DeviceDto> getActivePanels() {
        try {
            DeviceDto[] panels = restTemplate.getForObject(solarServiceUrl + "/solar-panels", DeviceDto[].class);
            if (panels == null) return List.of();
            return List.of(panels).stream().filter(p -> !Boolean.TRUE.equals(p.getUnderMaintenance())).toList();
        } catch (Exception ex) {
            log.warn("Failed to fetch solar panels: {}", ex.getMessage());
            return List.of();
        }
    }
    public List<GenerationRecordDto> getGenerationHistory(Long panelId) {
        try {
            GenerationRecordDto[] records = restTemplate.getForObject(
                    solarServiceUrl + "/solar-panels/" + panelId + "/generation", GenerationRecordDto[].class);
            return records == null ? List.of() : List.of(records);
        } catch (Exception ex) {
            log.warn("Failed to fetch solar generation history for panel {}: {}", panelId, ex.getMessage());
            return List.of();
        }
    }
    public List<AlertDto> getFaults() {
        try {
            AlertDto[] faults = restTemplate.getForObject(solarServiceUrl + "/solar-panels/faults", AlertDto[].class);
            return faults == null ? List.of() : List.of(faults);
        } catch (Exception ex) {
            log.warn("Failed to fetch solar faults: {}", ex.getMessage());
            return List.of();
        }
    }
    public DailyTotalDto getDailyTotal() {
        try {
            return restTemplate.getForObject(solarServiceUrl + "/solar-panels/reports/daily-total", DailyTotalDto.class);
        } catch (Exception ex) {
            log.warn("Failed to fetch solar daily total: {}", ex.getMessage());
            return DailyTotalDto.builder().deviceType("SOLAR_PANEL").totalGenerationKwh(0.0).build();
        }
    }
}

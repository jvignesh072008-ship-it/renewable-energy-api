package com.renewable.distribution.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DistributionRequest {
    @NotNull(message = "Required load is required")
    @Positive(message = "Required load must be greater than 0")
    private Double requiredLoadKwh;
}

package com.renewable.distribution.client;
import com.renewable.distribution.dto.client.DailyTotalDto;
import com.renewable.distribution.dto.client.DeviceDto;
import com.renewable.distribution.dto.client.AlertDto;
import com.renewable.distribution.dto.client.GenerationRecordDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
@Component
@RequiredArgsConstructor
@Slf4j
public class WindServiceClient {
    private final RestTemplate restTemplate;
    @Value("${services.wind.url}")
    private String windServiceUrl;
    public List<DeviceDto> getActiveTurbines() {
        try {
            DeviceDto[] turbines = restTemplate.getForObject(windServiceUrl + "/wind-turbines", DeviceDto[].class);
            if (turbines == null) return List.of();
            return List.of(turbines).stream().filter(p -> !Boolean.TRUE.equals(p.getUnderMaintenance())).toList();
        } catch (Exception ex) {
            log.warn("Failed to fetch wind turbines: {}", ex.getMessage());
            return List.of();
        }
    }
    public List<GenerationRecordDto> getGenerationHistory(Long turbineId) {
        try {
            GenerationRecordDto[] records = restTemplate.getForObject(
                    windServiceUrl + "/wind-turbines/" + turbineId + "/generation", GenerationRecordDto[].class);
            return records == null ? List.of() : List.of(records);
        } catch (Exception ex) {
            log.warn("Failed to fetch wind generation history for turbine {}: {}", turbineId, ex.getMessage());
            return List.of();
        }
    }
    public List<AlertDto> getFaults() {
        try {
            AlertDto[] faults = restTemplate.getForObject(windServiceUrl + "/wind-turbines/faults", AlertDto[].class);
            return faults == null ? List.of() : List.of(faults);
        } catch (Exception ex) {
            log.warn("Failed to fetch wind faults: {}", ex.getMessage());
            return List.of();
        }
    }
    public DailyTotalDto getDailyTotal() {
        try {
            return restTemplate.getForObject(windServiceUrl + "/wind-turbines/reports/daily-total", DailyTotalDto.class);
        } catch (Exception ex) {
            log.warn("Failed to fetch wind daily total: {}", ex.getMessage());
            return DailyTotalDto.builder().deviceType("WIND_TURBINE").totalGenerationKwh(0.0).build();
        }
    }
}

package com.renewable.distribution.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Entity
@Table(name = "distribution_records")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DistributionRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "requested_load_kwh", nullable = false)
    private Double requestedLoadKwh;
    @Column(name = "solar_used_kwh", nullable = false)
    private Double solarUsedKwh;
    @Column(name = "wind_used_kwh", nullable = false)
    private Double windUsedKwh;
    @Column(name = "battery_used_kwh", nullable = false)
    private Double batteryUsedKwh;
    @Column(name = "excess_stored_kwh", nullable = false)
    private Double excessStoredKwh;
    @Column(name = "unmet_demand_kwh", nullable = false)
    private Double unmetDemandKwh;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
}

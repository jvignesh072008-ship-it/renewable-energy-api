package com.renewable.distribution.dto.client;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BatteryDto {
    private Long id;
    private String name;
    private String location;
    private Double capacity;
    private Double chargePercentage;
    private Boolean underMaintenance;
    private Boolean lowBattery;
}

package com.renewable.distribution.repository;
import com.renewable.distribution.entity.DistributionRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDateTime;
import java.util.List;
public interface DistributionRecordRepository extends JpaRepository<DistributionRecord, Long> {
    List<DistributionRecord> findByCreatedAtBetweenOrderByCreatedAtDesc(LocalDateTime start, LocalDateTime end);
}

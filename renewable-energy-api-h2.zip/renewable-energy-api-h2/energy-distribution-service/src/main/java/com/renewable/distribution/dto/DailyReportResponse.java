package com.renewable.distribution.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DailyReportResponse {
    private String date;
    private Double solarGenerationKwh;
    private Double windGenerationKwh;
    private Double totalRenewableGenerationKwh;
    private Double averageBatteryChargePercentage;
    private Integer activeBatteryCount;
    private Integer faultCount;
    private Integer lowBatteryAlertCount;
    private Integer distributionOperationsToday;
}

package com.renewable.distribution.service;
import com.renewable.distribution.client.BatteryServiceClient;
import com.renewable.distribution.client.SolarServiceClient;
import com.renewable.distribution.client.WindServiceClient;
import com.renewable.distribution.dto.*;
import com.renewable.distribution.dto.client.AlertDto;
import com.renewable.distribution.dto.client.BatteryDto;
import com.renewable.distribution.dto.client.DeviceDto;
import com.renewable.distribution.dto.client.GenerationRecordDto;
import com.renewable.distribution.dto.client.TransactionDto;
import com.renewable.distribution.entity.DistributionRecord;
import com.renewable.distribution.exception.DistributionException;
import com.renewable.distribution.repository.DistributionRecordRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
@Service
@RequiredArgsConstructor
public class DistributionService {
    private final SolarServiceClient solarServiceClient;
    private final WindServiceClient windServiceClient;
    private final BatteryServiceClient batteryServiceClient;
    private final DistributionRecordRepository distributionRecordRepository;
    @Transactional
    public DistributionResponse balance(DistributionRequest request) {
        double requiredLoad = request.getRequiredLoadKwh();
        List<DeviceDto> activePanels = solarServiceClient.getActivePanels();
        List<DeviceDto> activeTurbines = windServiceClient.getActiveTurbines();
        if (activePanels.isEmpty() && activeTurbines.isEmpty()) {
            throw new DistributionException("No active (non-maintenance) solar or wind devices are available to distribute energy");
        }
        double solarOutput = activePanels.stream().mapToDouble(p -> latestOutput(solarServiceClient.getGenerationHistory(p.getId()))).sum();
        double windOutput = activeTurbines.stream().mapToDouble(t -> latestOutput(windServiceClient.getGenerationHistory(t.getId()))).sum();
        double totalRenewable = solarOutput + windOutput;
        List<String> batteryOps = new ArrayList<>();
        double batteryUsed = 0.0;
        double excessStored = 0.0;
        double unmetDemand = 0.0;
        if (totalRenewable >= requiredLoad) {
            double excess = totalRenewable - requiredLoad;
            excessStored = storeExcess(excess, batteryOps);
        } else {
            double shortfall = requiredLoad - totalRenewable;
            batteryUsed = dischargeShortfall(shortfall, batteryOps);
            unmetDemand = Math.max(0.0, shortfall - batteryUsed);
        }
        DistributionRecord record = DistributionRecord.builder()
                .requestedLoadKwh(requiredLoad)
                .solarUsedKwh(Math.min(solarOutput, requiredLoad))
                .windUsedKwh(Math.min(windOutput, Math.max(0.0, requiredLoad - solarOutput)))
                .batteryUsedKwh(batteryUsed)
                .excessStoredKwh(excessStored)
                .unmetDemandKwh(unmetDemand)
                .createdAt(LocalDateTime.now())
                .build();
        distributionRecordRepository.save(record);
        String summary = unmetDemand > 0
                ? String.format("Renewables supplied %.2f kWh, battery supplied %.2f kWh; %.2f kWh of demand remains unmet", totalRenewable, batteryUsed, unmetDemand)
                : (excessStored > 0
                    ? String.format("Renewables fully met demand (%.2f kWh); %.2f kWh excess stored to battery", requiredLoad, excessStored)
                    : String.format("Renewables fully met demand (%.2f kWh) with no excess", requiredLoad));
        return DistributionResponse.builder()
                .requiredLoadKwh(requiredLoad)
                .solarUsedKwh(solarOutput)
                .windUsedKwh(windOutput)
                .totalRenewableUsedKwh(totalRenewable)
                .batteryUsedKwh(batteryUsed)
                .excessStoredKwh(excessStored)
                .unmetDemandKwh(unmetDemand)
                .summary(summary)
                .batteryOperations(batteryOps)
                .timestamp(LocalDateTime.now())
                .build();
    }
    private double storeExcess(double excessKwh, List<String> batteryOps) {
        List<BatteryDto> batteries = batteryServiceClient.getAvailableBatteries();
        double remaining = excessKwh;
        for (BatteryDto battery : batteries) {
            if (remaining <= 0) break;
            double headroomKwh = battery.getCapacity() * (100.0 - battery.getChargePercentage()) / 100.0;
            if (headroomKwh <= 0) continue;
            double toCharge = Math.min(remaining, headroomKwh);
            TransactionDto tx = batteryServiceClient.charge(battery.getId(), toCharge);
            if (tx != null) {
                remaining -= toCharge;
                batteryOps.add(String.format("Charged battery %d with %.2f kWh (now at %.1f%%)", battery.getId(), toCharge, tx.getResultingPercentage()));
            }
        }
        return excessKwh - remaining; 
    }
    private double dischargeShortfall(double shortfallKwh, List<String> batteryOps) {
        List<BatteryDto> batteries = batteryServiceClient.getAvailableBatteries();
        double remaining = shortfallKwh;
        for (BatteryDto battery : batteries) {
            if (remaining <= 0) break;
            double storedKwh = battery.getCapacity() * battery.getChargePercentage() / 100.0;
            if (storedKwh <= 0) continue;
            double toDischarge = Math.min(remaining, storedKwh);
            TransactionDto tx = batteryServiceClient.discharge(battery.getId(), toDischarge);
            if (tx != null) {
                remaining -= toDischarge;
                batteryOps.add(String.format("Discharged battery %d by %.2f kWh (now at %.1f%%)", battery.getId(), toDischarge, tx.getResultingPercentage()));
            }
        }
        return shortfallKwh - remaining; 
    }
    private double latestOutput(List<GenerationRecordDto> history) {
        Optional<GenerationRecordDto> latest = history.stream()
                .max(Comparator.comparing(GenerationRecordDto::getRecordedAt));
        return latest.map(GenerationRecordDto::getUnits).orElse(0.0);
    }
    @Transactional(readOnly = true)
    public DailyReportResponse getDailyReport() {
        var solarDaily = solarServiceClient.getDailyTotal();
        var windDaily = windServiceClient.getDailyTotal();
        List<BatteryDto> allBatteries = batteryServiceClient.getAllBatteries();
        List<AlertDto> solarFaults = solarServiceClient.getFaults();
        List<AlertDto> windFaults = windServiceClient.getFaults();
        List<AlertDto> lowBatteryAlerts = batteryServiceClient.getLowBatteryAlerts();
        double avgCharge = allBatteries.stream().mapToDouble(BatteryDto::getChargePercentage).average().orElse(0.0);
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = today.plusDays(1).atStartOfDay();
        int distributionOpsToday = distributionRecordRepository.findByCreatedAtBetweenOrderByCreatedAtDesc(start, end).size();
        return DailyReportResponse.builder()
                .date(today.toString())
                .solarGenerationKwh(solarDaily.getTotalGenerationKwh())
                .windGenerationKwh(windDaily.getTotalGenerationKwh())
                .totalRenewableGenerationKwh(solarDaily.getTotalGenerationKwh() + windDaily.getTotalGenerationKwh())
                .averageBatteryChargePercentage(avgCharge)
                .activeBatteryCount(allBatteries.size())
                .faultCount(solarFaults.size() + windFaults.size())
                .lowBatteryAlertCount(lowBatteryAlerts.size())
                .distributionOperationsToday(distributionOpsToday)
                .build();
    }
    @Transactional(readOnly = true)
    public List<AlertDto> getAllFaults() {
        List<AlertDto> combined = new ArrayList<>();
        combined.addAll(solarServiceClient.getFaults());
        combined.addAll(windServiceClient.getFaults());
        combined.addAll(batteryServiceClient.getLowBatteryAlerts());
        return combined;
    }
}

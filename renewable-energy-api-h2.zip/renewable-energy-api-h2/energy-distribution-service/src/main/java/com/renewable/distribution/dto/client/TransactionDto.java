package com.renewable.distribution.dto.client;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionDto {
    private Long id;
    private Long batteryId;
    private String type;
    private Double amountKwh;
    private Double resultingPercentage;
    private Boolean lowBatteryAlert;
}

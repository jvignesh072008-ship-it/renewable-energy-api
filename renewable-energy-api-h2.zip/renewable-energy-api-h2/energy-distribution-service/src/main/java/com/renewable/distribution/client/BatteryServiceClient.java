package com.renewable.distribution.client;
import com.renewable.distribution.dto.client.AlertDto;
import com.renewable.distribution.dto.client.BatteryDto;
import com.renewable.distribution.dto.client.ChargeRequestDto;
import com.renewable.distribution.dto.client.TransactionDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
@Component
@RequiredArgsConstructor
@Slf4j
public class BatteryServiceClient {
    private final RestTemplate restTemplate;
    @Value("${services.battery.url}")
    private String batteryServiceUrl;
    public List<BatteryDto> getAvailableBatteries() {
        try {
            BatteryDto[] batteries = restTemplate.getForObject(batteryServiceUrl + "/batteries/available", BatteryDto[].class);
            return batteries == null ? List.of() : List.of(batteries);
        } catch (Exception ex) {
            log.warn("Failed to fetch available batteries: {}", ex.getMessage());
            return List.of();
        }
    }
    public List<BatteryDto> getAllBatteries() {
        try {
            BatteryDto[] batteries = restTemplate.getForObject(batteryServiceUrl + "/batteries", BatteryDto[].class);
            return batteries == null ? List.of() : List.of(batteries);
        } catch (Exception ex) {
            log.warn("Failed to fetch all batteries: {}", ex.getMessage());
            return List.of();
        }
    }
    public List<AlertDto> getLowBatteryAlerts() {
        try {
            AlertDto[] alerts = restTemplate.getForObject(batteryServiceUrl + "/battery/alerts", AlertDto[].class);
            return alerts == null ? List.of() : List.of(alerts);
        } catch (Exception ex) {
            log.warn("Failed to fetch low battery alerts: {}", ex.getMessage());
            return List.of();
        }
    }
    public TransactionDto charge(Long batteryId, double amountKwh) {
        try {
            ChargeRequestDto request = ChargeRequestDto.builder().batteryId(batteryId).amountKwh(amountKwh).build();
            return restTemplate.postForObject(batteryServiceUrl + "/battery/charge", request, TransactionDto.class);
        } catch (Exception ex) {
            log.warn("Failed to charge battery {} with {} kWh: {}", batteryId, amountKwh, ex.getMessage());
            return null;
        }
    }
    public TransactionDto discharge(Long batteryId, double amountKwh) {
        try {
            ChargeRequestDto request = ChargeRequestDto.builder().batteryId(batteryId).amountKwh(amountKwh).build();
            return restTemplate.postForObject(batteryServiceUrl + "/battery/discharge", request, TransactionDto.class);
        } catch (Exception ex) {
            log.warn("Failed to discharge battery {} of {} kWh: {}", batteryId, amountKwh, ex.getMessage());
            return null;
        }
    }
}

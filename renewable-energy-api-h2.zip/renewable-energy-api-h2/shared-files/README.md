# Renewable Energy Monitoring System

A microservices-based system for monitoring and managing solar panels, wind turbines,
and battery storage, with automated load distribution, fault detection, and daily
reporting. Built with **Java 17**, **Spring Boot 3.x**, **MySQL**, and
**Spring Cloud Gateway**.

---

## 1. Architecture

```
                              ┌─────────────────────┐
                              │     API Gateway      │
                              │   (port 8080)         │
                              └──────────┬───────────┘
                 ┌────────────┬──────────┼──────────┬────────────┐
                 │            │          │           │
        ┌────────▼──────┐ ┌───▼──────┐ ┌─▼────────┐ ┌▼──────────────────┐
        │ Solar Panel    │ │ Wind     │ │ Battery  │ │ Energy Distribution│
        │ Service (8081) │ │ Turbine  │ │ Service  │ │ Service (8084)      │
        │                │ │ Service  │ │ (8083)   │ │                     │
        │                │ │ (8082)   │ │          │ │  (calls Solar, Wind,│
        └───────┬────────┘ └────┬─────┘ └────┬─────┘ │   Battery via       │
                │               │            │       │   RestTemplate)     │
          ┌─────▼─────┐   ┌─────▼─────┐ ┌────▼─────┐ └──────────┬──────────┘
          │ solar_db  │   │ wind_db   │ │battery_db│      ┌──────▼───────┐
          └───────────┘   └───────────┘ └──────────┘      │distribution_db│
                                                            └───────────────┘
```

Each service owns its own MySQL database (per the SRS requirement of one database
per service) and exposes a REST API. The **API Gateway** is the single entry point;
all client requests should go through port `8080`. The **Energy Distribution
Service** is the only service that talks to other services directly, using
`RestTemplate` for synchronous inter-service communication.

| Service | Port | Database | Responsibility |
|---|---|---|---|
| Solar Panel Service | 8081 | solar_db | Solar panel CRUD, generation recording, fault detection |
| Wind Turbine Service | 8082 | wind_db | Wind turbine CRUD, generation recording, fault detection |
| Battery Service | 8083 | battery_db | Battery CRUD, charge/discharge, low-battery alerts |
| Energy Distribution Service | 8084 | distribution_db | Load balancing, daily reports, aggregated faults |
| API Gateway | 8080 | — | Routes all client traffic to the above |

---

## 2. Running the System

### Prerequisites
- Docker and Docker Compose
- (Optional, for local dev without Docker) Java 17 and Maven, plus a local MySQL 8 instance

### Start everything with Docker Compose

```bash
cd renewable-energy-monitoring-system
docker-compose up --build
```

This builds and starts:
- 4 MySQL 8 instances (`solar-db`, `wind-db`, `battery-db`, `distribution-db`), one per service
- All 4 microservices
- The API Gateway on port `8080`

Wait for the MySQL health checks to pass (Compose will hold back the app
containers via `depends_on: condition: service_healthy`), then the services
will start and create their schemas automatically (`ddl-auto: update`).

To stop everything:
```bash
docker-compose down
```

To wipe all data volumes as well:
```bash
docker-compose down -v
```

### Running a single service locally (without Docker)

Each service can also be run standalone with Maven, provided you have a local
MySQL instance and set the matching environment variables (or edit
`application.yml` directly):

```bash
cd solar-panel-service
DB_HOST=localhost DB_PORT=3306 DB_USERNAME=root DB_PASSWORD=root mvn spring-boot:run
```

Repeat for `wind-turbine-service`, `battery-service`, and
`energy-distribution-service` (the latter also needs `SOLAR_SERVICE_URL`,
`WIND_SERVICE_URL`, and `BATTERY_SERVICE_URL` pointing at wherever those
services are running). The `api-gateway` needs the same four URL variables.

---

## 3. API Reference (via the Gateway, port 8080)

### Solar Panel Service — `/solar-panels`
| Method | Path | Description |
|---|---|---|
| POST | `/solar-panels` | Register a solar panel |
| GET | `/solar-panels` | List all solar panels |
| GET | `/solar-panels/{id}` | Get a solar panel by id |
| PUT | `/solar-panels/{id}` | Update a solar panel |
| DELETE | `/solar-panels/{id}` | Delete a solar panel |
| POST | `/solar-panels/{id}/generation` | Record an hourly generation reading |
| GET | `/solar-panels/{id}/generation` | Get generation history for a panel |
| GET | `/solar-panels/faults` | List FAULT alerts (zero output during active hours) |
| GET | `/solar-panels/reports/daily-total?date=YYYY-MM-DD` | Total generation for a day (defaults to today) |

### Wind Turbine Service — `/wind-turbines`
Same endpoint shape as Solar, substituting `wind-turbines` for `solar-panels`.

### Battery Service — `/batteries` and `/battery`
| Method | Path | Description |
|---|---|---|
| POST | `/batteries` | Register a battery |
| GET | `/batteries` | List all batteries |
| GET | `/batteries/{id}` | Get a battery by id |
| PUT | `/batteries/{id}` | Update a battery |
| DELETE | `/batteries/{id}` | Delete a battery |
| GET | `/batteries/available` | List batteries not under maintenance |
| POST | `/battery/charge` | Charge a battery `{ batteryId, amountKwh }` |
| POST | `/battery/discharge` | Discharge a battery `{ batteryId, amountKwh }` |
| GET | `/battery/status` | Status of all batteries |
| GET | `/battery/status/{id}` | Status of a single battery |
| GET | `/battery/alerts` | LOW_BATTERY alerts (charge < 20%) |

### Energy Distribution Service
| Method | Path | Description |
|---|---|---|
| POST | `/distribution/balance` | Balance load for a given demand: `{ requiredLoadKwh }` |
| GET | `/reports/daily` | Aggregated daily report across all device types |
| GET | `/faults` | Aggregated FAULT + LOW_BATTERY alerts across all services |

A ready-to-import Postman collection with every endpoint above (including the
sample scenarios below) is at
[`postman/Renewable_Energy_Monitoring_System.postman_collection.json`](postman/Renewable_Energy_Monitoring_System.postman_collection.json).

---

## 4. Business Rules Implemented

- **Excess storage**: if renewable generation exceeds the required load in a
  `/distribution/balance` call, the excess is automatically charged into
  available (non-maintenance) batteries, filling each in turn.
- **Low battery alert**: any battery below 20% charge is surfaced via
  `GET /battery/alerts` and included in the aggregated `GET /faults`.
- **Fault detection**: a generation reading of `0` recorded between 6 AM and
  6 PM (configurable via `app.active-hours.start` / `app.active-hours.end`)
  is flagged as a `FAULT` for that device.
- **Distribution priority**: `/distribution/balance` always uses solar + wind
  output first; battery is only discharged to cover a shortfall, and any
  demand still unmet after draining available batteries is reported as
  `unmetDemandKwh`.
- **Maintenance exclusion**: devices with `underMaintenance = true` are
  excluded from distribution on both sides — the Solar/Wind services only
  return non-maintenance devices to Distribution, and the Battery service
  rejects charge/discharge calls against a battery under maintenance.

---

## 5. Validation Rules

| Field | Rule |
|---|---|
| Device name (solar/wind/battery) | Required |
| Location | Required |
| Capacity | Must be > 0 |
| Battery charge % | Always kept within 0–100 (server-clamped) |
| Generation units | Must be ≥ 0 |

> **Design note on generation units:** the original SRS validation table says
> generation units "must be > 0". However, the business rules also require
> detecting a **FAULT when output is exactly 0** during active hours. Those
> two rules are mutually exclusive if taken literally, so this implementation
> validates generation units as **≥ 0** (rejecting only negative readings) —
> a 0 reading is valid input and is precisely what triggers fault detection.

All validation failures return **400 Bad Request** with a field-level error
list via `MethodArgumentNotValidException` handling.

---

## 6. Exception Handling

Every service has a `@RestControllerAdvice` `GlobalExceptionHandler` returning
a consistent JSON error body:

```json
{
  "timestamp": "2026-07-16T10:15:30",
  "status": 404,
  "error": "Not Found",
  "message": "Solar panel not found with id: 99",
  "path": "/solar-panels/99",
  "details": null
}
```

| Exception | Service | HTTP Status |
|---|---|---|
| `SolarPanelNotFoundException` | Solar | 404 |
| `WindTurbineNotFoundException` | Wind | 404 |
| `BatteryNotFoundException` | Battery | 404 |
| `InsufficientCapacityException` | Battery | 409 |
| `DistributionException` | Distribution | 422 |
| `FaultDetectionException` | Distribution | 503 |
| `MethodArgumentNotValidException` | All | 400 |
| Any other `Exception` | All | 500 |

---

## 7. Sample Scenarios (matching the SRS test cases)

All examples assume the Gateway is running on `http://localhost:8080`.

### Scenario 1 — Register a solar panel → record generation → store excess in battery
```bash
# 1. Register a panel
curl -X POST http://localhost:8080/solar-panels \
  -H "Content-Type: application/json" \
  -d '{"name":"Rooftop A1","location":"Roof","capacity":5.5,"underMaintenance":false}'

# 2. Register a battery
curl -X POST http://localhost:8080/batteries \
  -H "Content-Type: application/json" \
  -d '{"name":"Bank 1","location":"Storage","capacity":20,"underMaintenance":false}'

# 3. Record generation (use the panel id returned in step 1, here assumed 1)
curl -X POST http://localhost:8080/solar-panels/1/generation \
  -H "Content-Type: application/json" \
  -d '{"units":8.0}'

# 4. Balance load for a smaller demand than generated -> excess is auto-stored
curl -X POST http://localhost:8080/distribution/balance \
  -H "Content-Type: application/json" \
  -d '{"requiredLoadKwh":2.0}'
```

### Scenario 2 — Register a wind turbine → record zero output → trigger fault
```bash
curl -X POST http://localhost:8080/wind-turbines \
  -H "Content-Type: application/json" \
  -d '{"name":"Turbine N1","location":"North Field","capacity":50,"underMaintenance":false}'

# Record a zero reading during active hours (6 AM - 6 PM)
curl -X POST http://localhost:8080/wind-turbines/1/generation \
  -H "Content-Type: application/json" \
  -d '{"units":0,"recordedAt":"2026-07-16T10:00:00"}'

curl http://localhost:8080/wind-turbines/faults
```

### Scenario 3 — Discharge battery when generation is low
```bash
# Charge the battery first so there is something to discharge
curl -X POST http://localhost:8080/battery/charge \
  -H "Content-Type: application/json" \
  -d '{"batteryId":1,"amountKwh":10}'

# Request a load far larger than current generation -> battery is discharged
curl -X POST http://localhost:8080/distribution/balance \
  -H "Content-Type: application/json" \
  -d '{"requiredLoadKwh":25.0}'
```

### Scenario 4 — Generate daily report
```bash
curl http://localhost:8080/reports/daily
```

### Scenario 5 — Try to distribute from maintenance-mode equipment → excluded
```bash
# Mark the panel as under maintenance
curl -X PUT http://localhost:8080/solar-panels/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"Rooftop A1","location":"Roof","capacity":5.5,"underMaintenance":true}'

# Balance again -- this panel's output is no longer counted
curl -X POST http://localhost:8080/distribution/balance \
  -H "Content-Type: application/json" \
  -d '{"requiredLoadKwh":2.0}'
```

---

## 8. Project Structure

```
renewable-energy-monitoring-system/
├── docker-compose.yml
├── README.md
├── postman/
│   └── Renewable_Energy_Monitoring_System.postman_collection.json
├── api-gateway/
│   ├── Dockerfile
│   ├── pom.xml
│   └── src/main/java/com/renewable/gateway/ApiGatewayApplication.java
│   └── src/main/resources/application.yml
├── solar-panel-service/
│   ├── Dockerfile
│   ├── pom.xml
│   └── src/main/java/com/renewable/solar/
│       ├── SolarPanelServiceApplication.java
│       ├── entity/          (SolarPanel, GenerationRecord)
│       ├── repository/      (SolarPanelRepository, GenerationRecordRepository)
│       ├── dto/              (request/response DTOs)
│       ├── service/          (SolarPanelService - business logic)
│       ├── controller/       (SolarPanelController)
│       └── exception/        (SolarPanelNotFoundException, GlobalExceptionHandler, ErrorResponse)
├── wind-turbine-service/     (mirrors solar-panel-service structure)
├── battery-service/
│   └── src/main/java/com/renewable/battery/
│       ├── entity/           (Battery, BatteryTransaction)
│       ├── repository/
│       ├── dto/
│       ├── service/           (BatteryService - charge/discharge/alerts)
│       ├── controller/
│       └── exception/
└── energy-distribution-service/
    └── src/main/java/com/renewable/distribution/
        ├── entity/            (DistributionRecord)
        ├── repository/
        ├── dto/                (+ dto/client mirrors of upstream response shapes)
        ├── client/             (SolarServiceClient, WindServiceClient, BatteryServiceClient - RestTemplate wrappers)
        ├── config/             (RestTemplateConfig)
        ├── service/            (DistributionService - balancing, reports, faults)
        ├── controller/
        └── exception/
```

---

## 9. Notes & Assumptions

- Active hours are 6 AM – 6 PM as specified; configurable per-service via
  `app.active-hours.start` / `app.active-hours.end` in `application.yml`
  (Solar and Wind services).
- `/distribution/balance` takes an explicit `requiredLoadKwh` in the request
  body, since the SRS does not specify a live metering/demand source. In a
  production system this would instead be fed by a SCADA/metering
  integration.
- "Current output" for a device during balancing is taken as its most
  recently recorded generation reading (via `GET /{device}/{id}/generation`).
- The Distribution service's calls to Solar/Wind/Battery degrade gracefully:
  if an upstream service is unreachable, that service's contribution is
  treated as zero/empty rather than failing the whole request, so a single
  service outage doesn't take down reporting or balancing entirely.
- Each service uses `ddl-auto: update` for convenience in this reference
  implementation; a production system would use a migration tool such as
  Flyway or Liquibase instead.

package com.renewable.solar.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SolarPanelResponse {
    private Long id;
    private String name;
    private String location;
    private Double capacity;
    private Boolean underMaintenance;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

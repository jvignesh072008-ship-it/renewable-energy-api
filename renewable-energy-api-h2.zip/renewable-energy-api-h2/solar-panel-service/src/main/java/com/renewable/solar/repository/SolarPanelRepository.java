package com.renewable.solar.repository;
import com.renewable.solar.entity.SolarPanel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface SolarPanelRepository extends JpaRepository<SolarPanel, Long> {
    List<SolarPanel> findByUnderMaintenanceFalse();
}

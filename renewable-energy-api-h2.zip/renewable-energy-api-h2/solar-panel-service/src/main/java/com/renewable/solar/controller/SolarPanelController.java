package com.renewable.solar.controller;
import com.renewable.solar.dto.*;
import com.renewable.solar.service.SolarPanelService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/solar-panels")
@RequiredArgsConstructor
public class SolarPanelController {
    private final SolarPanelService solarPanelService;
    @PostMapping
    public ResponseEntity<SolarPanelResponse> create(@Valid @RequestBody SolarPanelRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(solarPanelService.createSolarPanel(request));
    }
    @GetMapping
    public ResponseEntity<List<SolarPanelResponse>> getAll() {
        return ResponseEntity.ok(solarPanelService.getAllSolarPanels());
    }
    @GetMapping("/{id}")
    public ResponseEntity<SolarPanelResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(solarPanelService.getSolarPanelById(id));
    }
    @PutMapping("/{id}")
    public ResponseEntity<SolarPanelResponse> update(@PathVariable Long id, @Valid @RequestBody SolarPanelRequest request) {
        return ResponseEntity.ok(solarPanelService.updateSolarPanel(id, request));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        solarPanelService.deleteSolarPanel(id);
        return ResponseEntity.noContent().build();
    }
    @PostMapping("/{id}/generation")
    public ResponseEntity<GenerationRecordResponse> recordGeneration(@PathVariable Long id, @Valid @RequestBody GenerationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(solarPanelService.recordGeneration(id, request));
    }
    @GetMapping("/{id}/generation")
    public ResponseEntity<List<GenerationRecordResponse>> getGenerationHistory(@PathVariable Long id) {
        return ResponseEntity.ok(solarPanelService.getGenerationHistory(id));
    }
    @GetMapping("/faults")
    public ResponseEntity<List<FaultResponse>> getFaults() {
        return ResponseEntity.ok(solarPanelService.detectFaults());
    }
    @GetMapping("/reports/daily-total")
    public ResponseEntity<DailyTotalResponse> getDailyTotal(@RequestParam(required = false) String date) {
        java.time.LocalDate day = date != null ? java.time.LocalDate.parse(date) : java.time.LocalDate.now();
        java.time.LocalDateTime start = day.atStartOfDay();
        java.time.LocalDateTime end = day.plusDays(1).atStartOfDay();
        Double total = solarPanelService.getTotalGenerationForDay(start, end);
        return ResponseEntity.ok(DailyTotalResponse.builder()
                .date(day.toString())
                .deviceType("SOLAR_PANEL")
                .totalGenerationKwh(total)
                .build());
    }
}

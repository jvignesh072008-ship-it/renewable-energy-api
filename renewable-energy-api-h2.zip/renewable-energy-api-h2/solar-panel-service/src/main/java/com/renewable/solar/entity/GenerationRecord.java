package com.renewable.solar.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Entity
@Table(name = "generation_records")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GenerationRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "solar_panel_id", nullable = false)
    @JsonBackReference
    private SolarPanel solarPanel;
    @Column(nullable = false)
    private Double units;
    @Column(name = "recorded_at", nullable = false)
    private LocalDateTime recordedAt;
}

package com.renewable.solar.repository;
import com.renewable.solar.entity.GenerationRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.util.List;
public interface GenerationRecordRepository extends JpaRepository<GenerationRecord, Long> {
    List<GenerationRecord> findBySolarPanelIdOrderByRecordedAtDesc(Long solarPanelId);
    @Query("SELECT g FROM GenerationRecord g WHERE g.recordedAt BETWEEN :start AND :end")
    List<GenerationRecord> findAllBetween(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
    @Query("SELECT g FROM GenerationRecord g WHERE g.solarPanel.id = :panelId AND g.recordedAt BETWEEN :start AND :end")
    List<GenerationRecord> findByPanelBetween(@Param("panelId") Long panelId, @Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
    @Query("SELECT COALESCE(SUM(g.units), 0) FROM GenerationRecord g WHERE g.recordedAt BETWEEN :start AND :end")
    Double sumUnitsBetween(@Param("start") LocalDateTime start, @Param("end") LocalDateTime end);
}

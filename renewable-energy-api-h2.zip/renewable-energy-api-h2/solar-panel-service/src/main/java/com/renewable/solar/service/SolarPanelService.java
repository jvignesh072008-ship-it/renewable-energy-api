package com.renewable.solar.service;
import com.renewable.solar.dto.*;
import com.renewable.solar.entity.GenerationRecord;
import com.renewable.solar.entity.SolarPanel;
import com.renewable.solar.exception.SolarPanelNotFoundException;
import com.renewable.solar.repository.GenerationRecordRepository;
import com.renewable.solar.repository.SolarPanelRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
@Service
@RequiredArgsConstructor
public class SolarPanelService {
    private final SolarPanelRepository solarPanelRepository;
    private final GenerationRecordRepository generationRecordRepository;
    @Value("${app.active-hours.start:6}")
    private int activeHourStart;
    @Value("${app.active-hours.end:18}")
    private int activeHourEnd;
    @Transactional
    public SolarPanelResponse createSolarPanel(SolarPanelRequest request) {
        SolarPanel panel = SolarPanel.builder()
                .name(request.getName())
                .location(request.getLocation())
                .capacity(request.getCapacity())
                .underMaintenance(request.getUnderMaintenance() != null && request.getUnderMaintenance())
                .build();
        return toResponse(solarPanelRepository.save(panel));
    }
    @Transactional(readOnly = true)
    public List<SolarPanelResponse> getAllSolarPanels() {
        return solarPanelRepository.findAll().stream().map(this::toResponse).toList();
    }
    @Transactional(readOnly = true)
    public SolarPanelResponse getSolarPanelById(Long id) {
        return toResponse(findPanelOrThrow(id));
    }
    @Transactional
    public SolarPanelResponse updateSolarPanel(Long id, SolarPanelRequest request) {
        SolarPanel panel = findPanelOrThrow(id);
        panel.setName(request.getName());
        panel.setLocation(request.getLocation());
        panel.setCapacity(request.getCapacity());
        if (request.getUnderMaintenance() != null) {
            panel.setUnderMaintenance(request.getUnderMaintenance());
        }
        return toResponse(solarPanelRepository.save(panel));
    }
    @Transactional
    public void deleteSolarPanel(Long id) {
        SolarPanel panel = findPanelOrThrow(id);
        solarPanelRepository.delete(panel);
    }
    @Transactional
    public GenerationRecordResponse recordGeneration(Long id, GenerationRequest request) {
        SolarPanel panel = findPanelOrThrow(id);
        LocalDateTime recordedAt = request.getRecordedAt() != null ? request.getRecordedAt() : LocalDateTime.now();
        GenerationRecord record = GenerationRecord.builder()
                .solarPanel(panel)
                .units(request.getUnits())
                .recordedAt(recordedAt)
                .build();
        GenerationRecord saved = generationRecordRepository.save(record);
        return toRecordResponse(saved);
    }
    @Transactional(readOnly = true)
    public List<GenerationRecordResponse> getGenerationHistory(Long id) {
        findPanelOrThrow(id); 
        return generationRecordRepository.findBySolarPanelIdOrderByRecordedAtDesc(id).stream()
                .map(this::toRecordResponse)
                .toList();
    }
    @Transactional(readOnly = true)
    public List<FaultResponse> detectFaults() {
        List<SolarPanel> panels = solarPanelRepository.findAll();
        return panels.stream()
                .flatMap(panel -> panel.getGenerationRecords().stream()
                        .filter(this::isZeroDuringActiveHours)
                        .map(record -> FaultResponse.builder()
                                .deviceId(panel.getId())
                                .deviceName(panel.getName())
                                .deviceType("SOLAR_PANEL")
                                .alertType("FAULT")
                                .message("Zero output detected during active hours (" + activeHourStart + ":00-" + activeHourEnd + ":00)")
                                .detectedAt(record.getRecordedAt())
                                .build()))
                .toList();
    }
    private boolean isZeroDuringActiveHours(GenerationRecord record) {
        int hour = record.getRecordedAt().getHour();
        return record.getUnits() != null
                && record.getUnits() == 0.0
                && hour >= activeHourStart
                && hour < activeHourEnd;
    }
    @Transactional(readOnly = true)
    public Double getTotalGenerationForDay(LocalDateTime dayStart, LocalDateTime dayEnd) {
        return generationRecordRepository.sumUnitsBetween(dayStart, dayEnd);
    }
    private SolarPanel findPanelOrThrow(Long id) {
        return solarPanelRepository.findById(id)
                .orElseThrow(() -> new SolarPanelNotFoundException(id));
    }
    private SolarPanelResponse toResponse(SolarPanel panel) {
        return SolarPanelResponse.builder()
                .id(panel.getId())
                .name(panel.getName())
                .location(panel.getLocation())
                .capacity(panel.getCapacity())
                .underMaintenance(panel.getUnderMaintenance())
                .createdAt(panel.getCreatedAt())
                .updatedAt(panel.getUpdatedAt())
                .build();
    }
    private GenerationRecordResponse toRecordResponse(GenerationRecord record) {
        return GenerationRecordResponse.builder()
                .id(record.getId())
                .solarPanelId(record.getSolarPanel().getId())
                .units(record.getUnits())
                .recordedAt(record.getRecordedAt())
                .build();
    }
}

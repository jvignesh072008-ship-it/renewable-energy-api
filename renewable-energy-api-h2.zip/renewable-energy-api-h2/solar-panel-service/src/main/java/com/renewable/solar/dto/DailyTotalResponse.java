package com.renewable.solar.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DailyTotalResponse {
    private String date;
    private String deviceType;
    private Double totalGenerationKwh;
}

package com.renewable.solar.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GenerationRecordResponse {
    private Long id;
    private Long solarPanelId;
    private Double units;
    private LocalDateTime recordedAt;
}

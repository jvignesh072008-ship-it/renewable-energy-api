package com.renewable.battery.service;
import com.renewable.battery.dto.*;
import com.renewable.battery.entity.Battery;
import com.renewable.battery.entity.BatteryTransaction;
import com.renewable.battery.exception.BatteryNotFoundException;
import com.renewable.battery.exception.InsufficientCapacityException;
import com.renewable.battery.repository.BatteryRepository;
import com.renewable.battery.repository.BatteryTransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
@Service
@RequiredArgsConstructor
public class BatteryService {
    private final BatteryRepository batteryRepository;
    private final BatteryTransactionRepository transactionRepository;
    @Value("${app.battery.low-threshold-percent:20}")
    private double lowBatteryThreshold;
    @Transactional
    public BatteryResponse createBattery(BatteryRequest request) {
        Battery battery = Battery.builder()
                .name(request.getName())
                .location(request.getLocation())
                .capacity(request.getCapacity())
                .chargePercentage(0.0)
                .underMaintenance(request.getUnderMaintenance() != null && request.getUnderMaintenance())
                .build();
        return toResponse(batteryRepository.save(battery));
    }
    @Transactional(readOnly = true)
    public List<BatteryResponse> getAllBatteries() {
        return batteryRepository.findAll().stream().map(this::toResponse).toList();
    }
    @Transactional(readOnly = true)
    public BatteryResponse getBatteryById(Long id) {
        return toResponse(findBatteryOrThrow(id));
    }
    @Transactional
    public BatteryResponse updateBattery(Long id, BatteryRequest request) {
        Battery battery = findBatteryOrThrow(id);
        battery.setName(request.getName());
        battery.setLocation(request.getLocation());
        battery.setCapacity(request.getCapacity());
        if (request.getUnderMaintenance() != null) {
            battery.setUnderMaintenance(request.getUnderMaintenance());
        }
        return toResponse(batteryRepository.save(battery));
    }
    @Transactional
    public void deleteBattery(Long id) {
        Battery battery = findBatteryOrThrow(id);
        batteryRepository.delete(battery);
    }
    @Transactional
    public TransactionResponse charge(ChargeRequest request) {
        Battery battery = findBatteryOrThrow(request.getBatteryId());
        if (Boolean.TRUE.equals(battery.getUnderMaintenance())) {
            throw new InsufficientCapacityException("Battery " + battery.getId() + " is under maintenance and cannot be charged");
        }
        double availableKwh = battery.getAvailableCapacityKwh();
        if (request.getAmountKwh() > availableKwh) {
            throw new InsufficientCapacityException(
                    "Battery " + battery.getId() + " can only accept " + String.format("%.2f", availableKwh) + " kWh more before reaching full capacity");
        }
        double newPercentage = battery.getChargePercentage() + (request.getAmountKwh() / battery.getCapacity()) * 100.0;
        newPercentage = Math.min(100.0, newPercentage);
        battery.setChargePercentage(newPercentage);
        batteryRepository.save(battery);
        BatteryTransaction tx = BatteryTransaction.builder()
                .batteryId(battery.getId())
                .type(BatteryTransaction.TransactionType.CHARGE)
                .amountKwh(request.getAmountKwh())
                .resultingPercentage(newPercentage)
                .createdAt(LocalDateTime.now())
                .build();
        transactionRepository.save(tx);
        return toTransactionResponse(tx);
    }
    @Transactional
    public TransactionResponse discharge(ChargeRequest request) {
        Battery battery = findBatteryOrThrow(request.getBatteryId());
        if (Boolean.TRUE.equals(battery.getUnderMaintenance())) {
            throw new InsufficientCapacityException("Battery " + battery.getId() + " is under maintenance and cannot be discharged");
        }
        double storedKwh = battery.getCapacity() * battery.getChargePercentage() / 100.0;
        if (request.getAmountKwh() > storedKwh) {
            throw new InsufficientCapacityException(
                    "Battery " + battery.getId() + " only has " + String.format("%.2f", storedKwh) + " kWh stored");
        }
        double newPercentage = battery.getChargePercentage() - (request.getAmountKwh() / battery.getCapacity()) * 100.0;
        newPercentage = Math.max(0.0, newPercentage);
        battery.setChargePercentage(newPercentage);
        batteryRepository.save(battery);
        BatteryTransaction tx = BatteryTransaction.builder()
                .batteryId(battery.getId())
                .type(BatteryTransaction.TransactionType.DISCHARGE)
                .amountKwh(request.getAmountKwh())
                .resultingPercentage(newPercentage)
                .createdAt(LocalDateTime.now())
                .build();
        transactionRepository.save(tx);
        return toTransactionResponse(tx);
    }
    @Transactional(readOnly = true)
    public BatteryResponse getStatus(Long id) {
        return toResponse(findBatteryOrThrow(id));
    }
    @Transactional(readOnly = true)
    public List<BatteryResponse> getAllStatuses() {
        return getAllBatteries();
    }
    @Transactional(readOnly = true)
    public List<AlertResponse> detectLowBatteryAlerts() {
        return batteryRepository.findByChargePercentageLessThan(lowBatteryThreshold).stream()
                .map(battery -> AlertResponse.builder()
                        .deviceId(battery.getId())
                        .deviceName(battery.getName())
                        .deviceType("BATTERY")
                        .alertType("LOW_BATTERY")
                        .message("Battery charge at " + String.format("%.1f", battery.getChargePercentage()) + "% is below the " + lowBatteryThreshold + "% threshold")
                        .detectedAt(LocalDateTime.now())
                        .build())
                .toList();
    }
    @Transactional(readOnly = true)
    public List<BatteryResponse> getAvailableBatteries() {
        return batteryRepository.findByUnderMaintenanceFalse().stream().map(this::toResponse).toList();
    }
    private Battery findBatteryOrThrow(Long id) {
        return batteryRepository.findById(id)
                .orElseThrow(() -> new BatteryNotFoundException(id));
    }
    private BatteryResponse toResponse(Battery battery) {
        return BatteryResponse.builder()
                .id(battery.getId())
                .name(battery.getName())
                .location(battery.getLocation())
                .capacity(battery.getCapacity())
                .chargePercentage(battery.getChargePercentage())
                .underMaintenance(battery.getUnderMaintenance())
                .lowBattery(battery.getChargePercentage() < lowBatteryThreshold)
                .createdAt(battery.getCreatedAt())
                .updatedAt(battery.getUpdatedAt())
                .build();
    }
    private TransactionResponse toTransactionResponse(BatteryTransaction tx) {
        return TransactionResponse.builder()
                .id(tx.getId())
                .batteryId(tx.getBatteryId())
                .type(tx.getType().name())
                .amountKwh(tx.getAmountKwh())
                .resultingPercentage(tx.getResultingPercentage())
                .lowBatteryAlert(tx.getResultingPercentage() < lowBatteryThreshold)
                .createdAt(tx.getCreatedAt())
                .build();
    }
}

package com.renewable.battery.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionResponse {
    private Long id;
    private Long batteryId;
    private String type;
    private Double amountKwh;
    private Double resultingPercentage;
    private Boolean lowBatteryAlert;
    private LocalDateTime createdAt;
}

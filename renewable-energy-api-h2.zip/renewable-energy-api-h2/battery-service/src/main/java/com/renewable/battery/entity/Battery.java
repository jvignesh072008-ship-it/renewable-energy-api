package com.renewable.battery.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Entity
@Table(name = "batteries")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Battery {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private String location;
    @Column(nullable = false)
    private Double capacity;
    @Column(name = "charge_percentage", nullable = false)
    @Builder.Default
    private Double chargePercentage = 0.0;
    @Column(name = "under_maintenance", nullable = false)
    @Builder.Default
    private Boolean underMaintenance = false;
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    @Transient
    public double getAvailableCapacityKwh() {
        return capacity * (100.0 - chargePercentage) / 100.0;
    }
}

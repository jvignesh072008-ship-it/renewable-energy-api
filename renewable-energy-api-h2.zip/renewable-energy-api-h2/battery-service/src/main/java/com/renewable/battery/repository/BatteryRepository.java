package com.renewable.battery.repository;
import com.renewable.battery.entity.Battery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface BatteryRepository extends JpaRepository<Battery, Long> {
    List<Battery> findByUnderMaintenanceFalse();
    List<Battery> findByChargePercentageLessThan(Double threshold);
}

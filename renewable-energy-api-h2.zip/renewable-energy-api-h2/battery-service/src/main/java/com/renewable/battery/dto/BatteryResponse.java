package com.renewable.battery.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BatteryResponse {
    private Long id;
    private String name;
    private String location;
    private Double capacity;
    private Double chargePercentage;
    private Boolean underMaintenance;
    private Boolean lowBattery;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

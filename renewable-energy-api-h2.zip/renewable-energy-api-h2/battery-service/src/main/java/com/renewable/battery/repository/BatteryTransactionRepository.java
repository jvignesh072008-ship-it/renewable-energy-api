package com.renewable.battery.repository;
import com.renewable.battery.entity.BatteryTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface BatteryTransactionRepository extends JpaRepository<BatteryTransaction, Long> {
    List<BatteryTransaction> findByBatteryIdOrderByCreatedAtDesc(Long batteryId);
}

package com.renewable.battery.controller;
import com.renewable.battery.dto.*;
import com.renewable.battery.service.BatteryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequiredArgsConstructor
public class BatteryController {
    private final BatteryService batteryService;
    @PostMapping("/batteries")
    public ResponseEntity<BatteryResponse> create(@Valid @RequestBody BatteryRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(batteryService.createBattery(request));
    }
    @GetMapping("/batteries")
    public ResponseEntity<List<BatteryResponse>> getAll() {
        return ResponseEntity.ok(batteryService.getAllBatteries());
    }
    @GetMapping("/batteries/{id}")
    public ResponseEntity<BatteryResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(batteryService.getBatteryById(id));
    }
    @PutMapping("/batteries/{id}")
    public ResponseEntity<BatteryResponse> update(@PathVariable Long id, @Valid @RequestBody BatteryRequest request) {
        return ResponseEntity.ok(batteryService.updateBattery(id, request));
    }
    @DeleteMapping("/batteries/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        batteryService.deleteBattery(id);
        return ResponseEntity.noContent().build();
    }
    @GetMapping("/batteries/available")
    public ResponseEntity<List<BatteryResponse>> getAvailable() {
        return ResponseEntity.ok(batteryService.getAvailableBatteries());
    }
    @PostMapping("/battery/charge")
    public ResponseEntity<TransactionResponse> chargeBattery(@Valid @RequestBody ChargeRequest request) {
        return ResponseEntity.ok(batteryService.charge(request));
    }
    @PostMapping("/battery/discharge")
    public ResponseEntity<TransactionResponse> dischargeBattery(@Valid @RequestBody ChargeRequest request) {
        return ResponseEntity.ok(batteryService.discharge(request));
    }
    @GetMapping("/battery/status")
    public ResponseEntity<List<BatteryResponse>> statusAll() {
        return ResponseEntity.ok(batteryService.getAllStatuses());
    }
    @GetMapping("/battery/status/{id}")
    public ResponseEntity<BatteryResponse> statusById(@PathVariable Long id) {
        return ResponseEntity.ok(batteryService.getStatus(id));
    }
    @GetMapping("/battery/alerts")
    public ResponseEntity<List<AlertResponse>> getAlerts() {
        return ResponseEntity.ok(batteryService.detectLowBatteryAlerts());
    }
}

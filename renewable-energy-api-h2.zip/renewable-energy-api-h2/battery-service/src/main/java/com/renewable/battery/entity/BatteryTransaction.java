package com.renewable.battery.entity;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Entity
@Table(name = "battery_transactions")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BatteryTransaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "battery_id", nullable = false)
    private Long batteryId;
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;
    @Column(nullable = false)
    private Double amountKwh;
    @Column(name = "resulting_percentage", nullable = false)
    private Double resultingPercentage;
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    public enum TransactionType {
        CHARGE, DISCHARGE
    }
}

package com.renewable.battery.dto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlertResponse {
    private Long deviceId;
    private String deviceName;
    private String deviceType; 
    private String alertType;  
    private String message;
    private LocalDateTime detectedAt;
}

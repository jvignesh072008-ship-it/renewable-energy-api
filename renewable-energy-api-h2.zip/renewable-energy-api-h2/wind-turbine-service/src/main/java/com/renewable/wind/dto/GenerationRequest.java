package com.renewable.wind.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GenerationRequest {
    @NotNull(message = "Generation units are required")
    @PositiveOrZero(message = "Generation units must not be negative")
    private Double units;
    private LocalDateTime recordedAt;
}

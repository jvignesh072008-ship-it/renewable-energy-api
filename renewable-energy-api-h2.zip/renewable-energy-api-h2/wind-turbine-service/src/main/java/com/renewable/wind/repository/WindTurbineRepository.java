package com.renewable.wind.repository;
import com.renewable.wind.entity.WindTurbine;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface WindTurbineRepository extends JpaRepository<WindTurbine, Long> {
    List<WindTurbine> findByUnderMaintenanceFalse();
}

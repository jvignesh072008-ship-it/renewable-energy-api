package com.renewable.wind.service;
import com.renewable.wind.dto.*;
import com.renewable.wind.entity.GenerationRecord;
import com.renewable.wind.entity.WindTurbine;
import com.renewable.wind.exception.WindTurbineNotFoundException;
import com.renewable.wind.repository.GenerationRecordRepository;
import com.renewable.wind.repository.WindTurbineRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
@Service
@RequiredArgsConstructor
public class WindTurbineService {
    private final WindTurbineRepository windTurbineRepository;
    private final GenerationRecordRepository generationRecordRepository;
    @Value("${app.active-hours.start:6}")
    private int activeHourStart;
    @Value("${app.active-hours.end:18}")
    private int activeHourEnd;
    @Transactional
    public WindTurbineResponse createWindTurbine(WindTurbineRequest request) {
        WindTurbine panel = WindTurbine.builder()
                .name(request.getName())
                .location(request.getLocation())
                .capacity(request.getCapacity())
                .underMaintenance(request.getUnderMaintenance() != null && request.getUnderMaintenance())
                .build();
        return toResponse(windTurbineRepository.save(panel));
    }
    @Transactional(readOnly = true)
    public List<WindTurbineResponse> getAllWindTurbines() {
        return windTurbineRepository.findAll().stream().map(this::toResponse).toList();
    }
    @Transactional(readOnly = true)
    public WindTurbineResponse getWindTurbineById(Long id) {
        return toResponse(findPanelOrThrow(id));
    }
    @Transactional
    public WindTurbineResponse updateWindTurbine(Long id, WindTurbineRequest request) {
        WindTurbine panel = findPanelOrThrow(id);
        panel.setName(request.getName());
        panel.setLocation(request.getLocation());
        panel.setCapacity(request.getCapacity());
        if (request.getUnderMaintenance() != null) {
            panel.setUnderMaintenance(request.getUnderMaintenance());
        }
        return toResponse(windTurbineRepository.save(panel));
    }
    @Transactional
    public void deleteWindTurbine(Long id) {
        WindTurbine panel = findPanelOrThrow(id);
        windTurbineRepository.delete(panel);
    }
    @Transactional
    public GenerationRecordResponse recordGeneration(Long id, GenerationRequest request) {
        WindTurbine panel = findPanelOrThrow(id);
        LocalDateTime recordedAt = request.getRecordedAt() != null ? request.getRecordedAt() : LocalDateTime.now();
        GenerationRecord record = GenerationRecord.builder()
                .windTurbine(panel)
                .units(request.getUnits())
                .recordedAt(recordedAt)
                .build();
        GenerationRecord saved = generationRecordRepository.save(record);
        return toRecordResponse(saved);
    }
    @Transactional(readOnly = true)
    public List<GenerationRecordResponse> getGenerationHistory(Long id) {
        findPanelOrThrow(id); 
        return generationRecordRepository.findByWindTurbineIdOrderByRecordedAtDesc(id).stream()
                .map(this::toRecordResponse)
                .toList();
    }
    @Transactional(readOnly = true)
    public List<FaultResponse> detectFaults() {
        List<WindTurbine> panels = windTurbineRepository.findAll();
        return panels.stream()
                .flatMap(panel -> panel.getGenerationRecords().stream()
                        .filter(this::isZeroDuringActiveHours)
                        .map(record -> FaultResponse.builder()
                                .deviceId(panel.getId())
                                .deviceName(panel.getName())
                                .deviceType("WIND_TURBINE")
                                .alertType("FAULT")
                                .message("Zero output detected during active hours (" + activeHourStart + ":00-" + activeHourEnd + ":00)")
                                .detectedAt(record.getRecordedAt())
                                .build()))
                .toList();
    }
    private boolean isZeroDuringActiveHours(GenerationRecord record) {
        int hour = record.getRecordedAt().getHour();
        return record.getUnits() != null
                && record.getUnits() == 0.0
                && hour >= activeHourStart
                && hour < activeHourEnd;
    }
    @Transactional(readOnly = true)
    public Double getTotalGenerationForDay(LocalDateTime dayStart, LocalDateTime dayEnd) {
        return generationRecordRepository.sumUnitsBetween(dayStart, dayEnd);
    }
    private WindTurbine findPanelOrThrow(Long id) {
        return windTurbineRepository.findById(id)
                .orElseThrow(() -> new WindTurbineNotFoundException(id));
    }
    private WindTurbineResponse toResponse(WindTurbine panel) {
        return WindTurbineResponse.builder()
                .id(panel.getId())
                .name(panel.getName())
                .location(panel.getLocation())
                .capacity(panel.getCapacity())
                .underMaintenance(panel.getUnderMaintenance())
                .createdAt(panel.getCreatedAt())
                .updatedAt(panel.getUpdatedAt())
                .build();
    }
    private GenerationRecordResponse toRecordResponse(GenerationRecord record) {
        return GenerationRecordResponse.builder()
                .id(record.getId())
                .windTurbineId(record.getWindTurbine().getId())
                .units(record.getUnits())
                .recordedAt(record.getRecordedAt())
                .build();
    }
}

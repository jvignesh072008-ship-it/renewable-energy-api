package com.renewable.wind.dto;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WindTurbineRequest {
    @NotBlank(message = "Device name is required")
    private String name;
    @NotBlank(message = "Location is required")
    private String location;
    @NotNull(message = "Capacity is required")
    @DecimalMin(value = "0.01", message = "Capacity must be greater than 0")
    private Double capacity;
    private Boolean underMaintenance;
}

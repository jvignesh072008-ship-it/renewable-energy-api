package com.renewable.wind.controller;
import com.renewable.wind.dto.*;
import com.renewable.wind.service.WindTurbineService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/wind-turbines")
@RequiredArgsConstructor
public class WindTurbineController {
    private final WindTurbineService windTurbineService;
    @PostMapping
    public ResponseEntity<WindTurbineResponse> create(@Valid @RequestBody WindTurbineRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(windTurbineService.createWindTurbine(request));
    }
    @GetMapping
    public ResponseEntity<List<WindTurbineResponse>> getAll() {
        return ResponseEntity.ok(windTurbineService.getAllWindTurbines());
    }
    @GetMapping("/{id}")
    public ResponseEntity<WindTurbineResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(windTurbineService.getWindTurbineById(id));
    }
    @PutMapping("/{id}")
    public ResponseEntity<WindTurbineResponse> update(@PathVariable Long id, @Valid @RequestBody WindTurbineRequest request) {
        return ResponseEntity.ok(windTurbineService.updateWindTurbine(id, request));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        windTurbineService.deleteWindTurbine(id);
        return ResponseEntity.noContent().build();
    }
    @PostMapping("/{id}/generation")
    public ResponseEntity<GenerationRecordResponse> recordGeneration(@PathVariable Long id, @Valid @RequestBody GenerationRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(windTurbineService.recordGeneration(id, request));
    }
    @GetMapping("/{id}/generation")
    public ResponseEntity<List<GenerationRecordResponse>> getGenerationHistory(@PathVariable Long id) {
        return ResponseEntity.ok(windTurbineService.getGenerationHistory(id));
    }
    @GetMapping("/faults")
    public ResponseEntity<List<FaultResponse>> getFaults() {
        return ResponseEntity.ok(windTurbineService.detectFaults());
    }
    @GetMapping("/reports/daily-total")
    public ResponseEntity<DailyTotalResponse> getDailyTotal(@RequestParam(required = false) String date) {
        java.time.LocalDate day = date != null ? java.time.LocalDate.parse(date) : java.time.LocalDate.now();
        java.time.LocalDateTime start = day.atStartOfDay();
        java.time.LocalDateTime end = day.plusDays(1).atStartOfDay();
        Double total = windTurbineService.getTotalGenerationForDay(start, end);
        return ResponseEntity.ok(DailyTotalResponse.builder()
                .date(day.toString())
                .deviceType("WIND_TURBINE")
                .totalGenerationKwh(total)
                .build());
    }
}
